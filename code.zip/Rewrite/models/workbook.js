const mongoose = require('mongoose');

const workbookSchema = new mongoose.Schema({
  entries: {
      type: Array,
      required: true,
      default: [],
  },
  userRef: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  }
}, {
  timestamps: true,
  collection: 'workbooks'
});

module.exports = mongoose.model('Workbook', workbookSchema);